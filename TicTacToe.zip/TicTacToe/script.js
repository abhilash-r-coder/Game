document.addEventListener("DOMContentLoaded", function () {
    const board = document.getElementById("game-board");
    const resultScreen = document.getElementById("result-screen");
    const resultMessage = document.getElementById("result-message");
    const newGameBtn = document.getElementById("new-game-btn");

    let currentPlayer = "X";
    let cells = Array.from({ length: 9 });

    cells.forEach((_, index) => {
        const cell = document.createElement("div");
        cell.classList.add("cell");
        cell.dataset.index = index;
        cell.addEventListener("click", handleCellClick);
        board.appendChild(cell);
    });

    function handleCellClick(event) {
        const cell = event.target;
        const index = cell.dataset.index;

        if (!cells[index]) {
            cells[index] = currentPlayer;
            cell.textContent = currentPlayer;

            if (checkWinner()) {
                showResult(`Player ${currentPlayer} wins!`, true);
            } else if (cells.every((cell) => cell)) {
                showResult("It's a draw!", false);
            } else {
                currentPlayer = currentPlayer === "X" ? "O" : "X";
            }
        }
    }

    function checkWinner() {
        const winPatterns = [
            [0, 1, 2],
            [3, 4, 5],
            [6, 7, 8],
            [0, 3, 6],
            [1, 4, 7],
            [2, 5, 8],
            [0, 4, 8],
            [2, 4, 6],
        ];

        return winPatterns.some((pattern) =>
            pattern.every((index) => cells[index] === currentPlayer)
        );
    }

    function showResult(message, isWinner) {
        resultMessage.textContent = message;
        resultScreen.style.display = "flex";

        if (isWinner) {
            resultMessage.style.color = currentPlayer === "X" ? "#3498db" : "#e74c3c";
        } else {
            resultMessage.style.color = "#333";
        }

        newGameBtn.addEventListener("click", resetGame);
    }

    function resetGame() {
        cells = Array.from({ length: 9 });
        currentPlayer = "X";
        document.querySelectorAll(".cell").forEach((cell) => {
            cell.textContent = "";
        });

        resultScreen.style.display = "none";
        newGameBtn.removeEventListener("click", resetGame);
    }
});
